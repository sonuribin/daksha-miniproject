<html>
<head><title>DETAILS</title>
<link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#98bbf5;
letter-spacing: 0pt;
width:1000px;
height: 800px;
border:10px ;
padding:40 px;
margin-top:80px;
margin-left: 300px;
text-align: center;
}
</style>
<a href="home1.php">HOME</a>
<h1 align="center" style="color:red">STATE YOUTH FESTIVAL</h1>
<form>
<P><BR>Kerala School Kalolsavam is an annual event conducted by the Government of Kerala, featuring several art competitions for high school and higher secondary school students of Kerala. The festival was started in 1956, and till 2008, it was called as Kerala State School Youth Festival. The participants are students from classes 8th to 12th. Winners from different revenue districts for a particular event will be competing in state level competition. The event is usually conducted in December–January months of a year and is considered to be the biggest cultural event of Asia.</P><BR>
<h2 align="center" style="color:black"><u>HISTORY</h1></u>
	<p>Kerala Schools Kalolsavam is a festival unique in its structure and organisation. The organisational set up from school level to state level for the conduct of the Kalolsavam is monitored by Education Department as per the manual drafted by experts in the field. Looking back into the history of School Kalolsavam in the last 53 years it is seen that the Kalolsavam has refined much in letter and spirit. Students get opportunity to express their talent in school level, sub district level, district level and at last at state level. When performers reach state level, perfection reaches its zenith.</p>

<p>In 1956-57 when the School Yuvajanolsavam (former name) began, it hadn't reached anywhere near the variety, pomp and the vast canvas which the festival has now reached. Dr.C.S.Venkiteswaran was the DPI in 1956. He had the opportunity to participate in the Inter-University festival at Delhi during that time. This inspired the great visionary to organize a similar festival at school level and thus he sowed the seed of School Kalolsavam at Ernakulam SRV High School in 1956. Programme was scheduled for one day and there were 200 participants. Mid-day meal and tea was served. Participation was directly from school level. Year by year more and more items were included, and number of days of the Kalolsavam was increased. Number of participants have increased to ten thousand.</p>

<p>From 1956-1957 to 2008-2009 School Kalolsavam has crossed many mile stones. Now Govt. has active involvement with peoples representatives from Grama Panchayath level to Corporation Level, Member of Legislative Assembly to Members of Parliament, Ministers etc. giving all support for the success of the Kalolsavam. While in 1956-57 there were only 200 participants, in 2008-2009 there are nearly 10,000 participants. While in 1956-57, it was a business of one day, today it is a festival of 7 days. The decorative main stage accommodates thousands of people. Delicious food is prepared for breakfast, mid day meals & supper for nearly ten thousand participants. The year 1975, when the festival was hosted at Calicut, was a turning point in the history of School Kalolsavam. Many art forms of Kerala tradition like Kathakali music, Mohiniyattom, Aksharaslokam etc. got entry to Kalolsavam for the first time. As a prelude to the Kalolsavam, proclamation rally was organised in 1975. Later on Margomkali, Kuchipudi, Yakshaganam, Band display etc. got entry to the Kalolsavam. By the end of eighties, ever rolling Golden Cup of 117.5 sovereign gold was awarded to the overall winning Revenue District. This Gold Cup was designed by Chirayankeezhu Srikandan Nair who was an Art Instructor in Education Department.</p>
<p>In the year 2000, Millennium trophy a beautiful dancing Nataraja trophy was introduced. Today there are numerous trophies, cash prizes, grace marks etc. to the winners. The system of Kalathilakam & Kalaprathiba was dispensed with to eliminate unhealthy competition. The festival has a foolproof system to encourage thousands of students in various Art & Literary forms in each academic year. Perfect time management, impartial Judgement, on the spot arrangements to dispose of appeals etc. has always been a matter of concern. From 2008-2009 it becomes a festival of students from Std.VIII to Plus 2 level. In a Nut Shell, School Kalolsavam is a Kaleidoscope of Kerala's young talent in the field of Art and Literature. Each year the venue of the Kalolsavam is changed from one District to another to ensure the participation of the people throughout the state.</p>