<?php
	$id=$_GET['id'];
	include('conn.php');
	mysqli_query($conn,"delete from `tbl_staff` where id='$id'");
	header('location:stview.php');
?>