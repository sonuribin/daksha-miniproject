<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#e24646;
letter-spacing: 0pt;
width:300px;
height: 600px;
border:10px ;
padding:40 px;
margin-top:80px;
margin-left: 400px;
text-align: center;
}



span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{

width: 88%;
height: 30px;
float: none;
    
    
    border-radius: 00px;
    padding: 0 10px;


}
.input-box1
{

width: 72%;
height: 30px;

    
    
    border-radius: 00px;
    padding: 0 20px;



</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">STAFF</a> 
            </div>

        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                
                    
               
                     <li>
                        <a  href="schedule.php"><i class="fa fa-dashboard fa-3x"></i> SCHEDULE PROGRAM</a>
                    </li>
                        <li>
                        <a  href="eresult.php"><i class="fa fa-desktop fa-3x"></i>ENTER RESULTS</a>
                    </li>
                      <li>
                        <a  href="scheview2.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW SCHEDULE</a>
                    </li>
                    <li>
                        <a  href="eventview1.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="gview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>GROUP EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="resultview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW RESULT</a>
                    </li>
               
            </div>
            
        </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     <body>
                        <body>
    <a href="staffentr.php">Back to Staff</a>

</form>
</div>
  </body>
</head>
</html>
<h1 style="color:red" align="center">SCHEDULES</h1>

 <?php
$errors=array();
$db=mysqli_connect('localhost','root','','klp');
 if($db){
        echo "";
    }else{
        echo 'Error'.$db->error;
    }
$query=("SELECT * FROM tbl_sch");
$results = mysqli_query($db, $query);
if(!$results)
{
die("selection error".mysql_connect_error());
}
else
{
echo " ";
}
?>
                        <div class="">
                        <center><table   width="100%"   border="0" class="table table-bordered">
                            <table border=5 bordercolor=black>
                           <thead style="color:red;" align="center">
                            <tr><th width="18%">EVENT</th>
                            <th width="18%">STAGE</th>
                            <th width="18%">DATE</th>
                            <th width="18%"> TIME</th>
                            </thead>

  <?php
$numrows=mysqli_num_rows($results);
while($row=mysqli_fetch_assoc($results))
{
?>
<tbody style="color:black;" align="center">
<tr>
    <td><?php echo $row['list'];?></td>
    <td><?php echo $row['stage'];?></td>
    <td><?php echo $row['date1'];?></td>
    <td><?php echo $row['time'];?></td>
    
</tr></tbody>
<?php
}
?>
<?php
echo"
</table>";

?>
        </div></center>
    </ul>
</body>
</html>