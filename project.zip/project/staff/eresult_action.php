<?php
$errors=array();
    $db=mysqli_connect('localhost','root','','klp');
    if($db){
        echo 'Success';
    }else{
        echo 'Error'.$db->error;
    }
    if(isset($_POST['submit'])===TRUE)
{
$list=mysqli_real_escape_string($db,$_POST['list']);
$prize1=mysqli_real_escape_string($db,$_POST['prize1']);
$grade1=mysqli_real_escape_string($db,$_POST['grade1']);
$district1=mysqli_real_escape_string($db,$_POST['district1']);
$prize2=mysqli_real_escape_string($db,$_POST['prize2']);
$grade2=mysqli_real_escape_string($db,$_POST['grade2']);
$district2=mysqli_real_escape_string($db,$_POST['district2']);
        $sql= "INSERT INTO tbl_result (list,prize1,grade1,district1,prize2,grade2,district2) VALUES ('$list','$prize1','$grade1','$district1','$prize2','$grade2','$district2')";
echo("Sql === ".$sql);
        if(mysqli_query($db,$sql)==TRUE){
    header("Location:staffentr.php");
}
else{
    echo("Sql===".$sql."Error ===".mysqli_error($db));
}
}
?>