<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername,$username, $password,$dbname);

if(isset($_POST['submit'])){
$district =$_POST['district'];
    
   
  $details= "INSERT into tbl_district (district)values('$district')";
  if(mysqli_query($conn, $details)) 
  {

      
        echo "<script>
        alert('Type added succesfully');
      </script>";

 
      //header('location:index.php?option=as');
    }

   
  }
  else{
      echo "<script>alert('email in use');</script>";
}



mysqli_close($conn);
?>
  ?>