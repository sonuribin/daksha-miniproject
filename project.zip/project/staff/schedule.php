
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#8d91a1;
letter-spacing: 0pt;
width:600px;
height: 400px;
border-radius: 10% ;
padding:40 px;
margin-top:70px;
margin-left: 300px;
text-align: center;
}
.ss{
  padding: 15px;
  font-size: 16px;
  color: black;
  background:#1aa3ff;
  border: none;
  border-radius: 4px;
}
.input-box
{
width: 88%;
height: 30px;

    
    
    border-radius: 00px;
    padding: 0 10px;

</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">STAFF</a> 
            </div>
            
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                    </li>
                
                    
                  <li>
                        <a  href="schedule.php"><i class="fa fa-dashboard fa-3x"></i> SCHEDULE PROGRAM</a>
                    </li>
                        <li>
                        <a  href="eresult.php"><i class="fa fa-desktop fa-3x"></i>ENTER RESULTS</a>
                    </li>
                      <li>
                        <a  href="scheview2.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW SCHEDULE</a>
                    </li>
                    <li>
                        <a  href="eventview1.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="gview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>GROUP EVENT REGISTRATIONS</a>
                    </li>
                    <li>
                        <a  href="resultview.php"><i class="material-icons"style="font-size:30px;color:white;">visibility</i>VIEW RESULT</a>
                    </li>
                </ul>
               
            </div>
             </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
<body>
        <a href="staffentr.php">Back To Staff</a>
         <div class="a"><br> 
    <ul>
   
     
    <h2 align="center"><br><br> SCHEDULE ITEMS</h2>
    
    <form method="POST" action="sch_action.php">
            <P>SELECT ITEM</P>
            <select name="list">
                <option> </option>
            <option>Mappilapattu - Male (5 mins)</option>
            <option>Mappilapattu - Female (5 mins)</option>
            <option>Light Music - Men (5 mins) </option>
            <option>Light Music - Women (10 mins) </option>
            <option>Classical Music - Men(10 mins)</option>
            <option>Classical Music - Women (10 mins)</option>
            <option>Kadhaprasangam (15 mins)</option>
            <option>Mono Act(5 mins)</option>
            <option>Mimicry (5 mins)</option>
            <option>Keralanadanam (15 mins)</option>
            <option>Thullal (10 mins)</option>
            <option>Kadhakali(Male) (15 mins)</option>
            <option>Kadhakali(Female) (15 mins)</option>
            <option>Folk Dance - Men (10 mins)</option>
            <option>Folk Dance - Women (10 mins)</option>
            <option>Bharatanatyam (15 mins)/option>
            <option>Classical Dance (Kuchipudi, Odissi) (15 mins)</option>
            <option>Mohiniyattam (15 mins)</option>
            <option>Recitation (5 mins)</option>
            <option>String Western - Violin, Guitar (10 mins)</option>
            <option>Wind Western - Harmonium (10 mins)</option>
            <option>Triple Drum  (10 mins)</option>
            <option>Jazz (10 mins)</option>
            <option>Percusion Type - Eastern - Chenda, Edakka (10 mins)</option>
            <option>Percusion Type - Eastern - Tabala, Panchavadyam (10 mins)</option>
            <option>Percusion Type - Eastern - Mridangam, Ganjira (10 mins)</option>
            <option>String Eastern - Veena (10 mins)</option>
            <option>String Eastern - Violin (10 mins)</option>
            <option>Wind Eastern - Harmonium, Pullamkuzhal (10 mins)</option>
            <option>Rangoli (2.5 hrs)</option>
            <option>Western Vocal - Solo (6 mins)</option>
            <option>Semi Classical - Solo (10 mins)</option>
            <option>Chakyarkkoothu (20 mins)</option>
            <option>KathakaliSangeetham -Male (10 mins)</option>
            <option>KathakaliSangeetham -Female (10 mins) </option>
            <option>Group Song - Indian (10 mins)</option>
            <option>Group Song - Western (10 mins)</option>
            <option>Kolkkali (10 mins)</option>
            <option>Daffmuttu (10 mins)</option>
            <option>Oppana - Men (10 mins)</option>
            <option>Oppana - women (10 mins)</option>
            <option>Group Dance - Men (10 mins)</option>
            <option>Group Dance - Women (10 mins)</option>
            <option>Thiruvathirakali (10 mins)</option>
            <option>Margamkali (10 mins)</option>
            <option>Mime Drama (5 mins)</option>
            <option>Malayalam Drama (30 mins)</option>
            <option>English Drama (30 mins)</option>
            <option>Hindi Drama (30 mins)</option>
            <option>Pookkalam - Flower Carpet (3 hrs)</option>
            <option>ParichamuttuKali (10 mins)</option>
            <option>Folk Orchestra (10 mins)</option>
            <option>Skit - English/ Hindi (10 mins)</option>
            <option>poorakkali (10 mins)</option>
            <option>Koodiyattam (10 mins)</option>
            <option>Patriotic Song(5 mins)</option>
            <option>Ganamela(10 mins)</option>
            <option>Chendamelam(10 mins)</option>
            <option>Panchavadyam(20 mins)</option>
            <option>Band Melam(20 mins)</option>
            <option>Chenda/ thayampakam(10 mins)</option>
            <option>Maddalam(10 mins)</option>
        </select>
            
    
<p>STAGE NUMBER</p>
 <select name="stage">
                <option> </option>
            <option>stage one</option>
            <option>stage two</option>
            <option>stage three </option>
            <option>stage four </option>
            <option>stage five</option>
 </select>
<br>  <br>              
                    <div class="input-box">
                    <span class="lnr lnr-calendar-full"></span>
                    <input type="date" name="date1" id="dob" class="input-box" min="<?= date('Y-m-d'); ?>" title="Date of birth" placeholder="Enter the Date of Birth"required >        </div>
                    <span id="demo" style="color:black;"></span>
                    <script>
                        function myFunction() 
                    {
                        var x = document.getElementById("dob").max;
                        document.getElementById("demo").innerHTML = "Invalid Date!!";
                    }
                    
</script>
                 
<p>TIME</p>
<time><input type="time" name="time"  placeholder="Demo time" step="900" onfocus="this.type='time'" value=""><br><br></time>
<input type='submit'  class="btn"name='submit' value='Submit' /><br><br>

    </form> 
    
    </div>  
    
    </ul>
   
</body>
</html>

