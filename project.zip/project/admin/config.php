<?php 
$conn=mysqli_connect("localhost","root","","klp") or die('DATABASE connection failed');
?>