 <?php
$errors=array();
  $db=mysqli_connect('localhost','root','','klp');
 if($db){
        echo 'success';
    }else{
        echo 'Error'.$db->error;
    }
    if(isset($_POST['submit'])===TRUE)
    {        
$name=mysqli_real_escape_string($db,$_POST['name']);
$a=mysqli_real_escape_string($db,$_POST['a']);
$b=mysqli_real_escape_string($db,$_POST['b']);
$c=mysqli_real_escape_string($db,$_POST['c']);
//mysql_select_db('fzone');
$sql=("INSERT INTO tbl_reg(`name`, `a`, `b`, `c`) VALUES  ('$name','$a','$b','$c')");
echo("Sql === ".$sql);
 if(mysqli_query($db,$sql)==TRUE){
    header("Location:prgmreg.php");
}
else{
    echo("Sql===".$sql."Error ===".mysqli_error($db));
}
}
?>

