<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#e24646;
letter-spacing: 0pt;
width:300px;
height: 600px;
border:10px ;
padding:40 px;
margin-top:80px;
margin-left: 400px;
text-align: center;
}



span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{

width: 88%;
height: 30px;
float: none;
    
    
    border-radius: 00px;
    padding: 0 10px;


}
.input-box1
{

width: 72%;
height: 30px;

    
    
    border-radius: 00px;
    padding: 0 20px;



</style>
</head>
</html>
<a href="home1.php">HOME</a>
<h1 style="color:red" align="center">RESULT</h1>

 <?php
$errors=array();
$db=mysqli_connect('localhost','root','','klp');
 if($db){
        echo "";
    }else{
        echo 'Error'.$db->error;
    }
$query=("SELECT * FROM tbl_result");
$results = mysqli_query($db, $query);
if(!$results)
{
die("selection error".mysql_connect_error());
}
else
{
echo " ";
}
?>
                        <div class="">
                        <center><table   width="100%"   border="0" class="table table-bordered">
                            <table border=5 bordercolor=black>
                           <thead style="color:red;" align="center">
                            <tr><th width="18%">EVENT</th>
                            <th width="18%">1stPRIZE</th>
                            <th width="18%">DISTRICT</th>
                            <th width="18%">2NDPRIZE</th>
                            <th width="18%">DISTRICT</th>
                            </thead>

  <?php
$numrows=mysqli_num_rows($results);
while($row=mysqli_fetch_assoc($results))
{
?>
<tbody style="color:black;" align="center">
<tr>
    <td><?php echo $row['list'];?></td>
    <td><?php echo $row['prize1'];?></td>
    <td><?php echo $row['district1'];?></td>
    <td><?php echo $row['prize2'];?></td>
    <td><?php echo $row['district2'];?></td>
    
</tr></tbody>
<?php
}
?>
<?php
echo"
</table>";

?>
        </div></center>
    </ul>
</body>
</html>