<?php
include 'conn.php';
session_start();
$ss=$_SESSION['users'];

?>
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#ff9933;
letter-spacing: 0pt;
width:600px;
height: 600px;
border:30px ;
padding:40 px;
margin-top:70px;
margin-left: 300px;
text-align: center;
}
.ss{
  padding: 15px;
  font-size: 16px;
  color: black;
  background:#1aa3ff;
  border: none;
  border-radius: 4px;
}
.input-box1
{
width: 100%;
height: 60px;

    
    
    border-radius: 00px;
    padding: 0 10px;

</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">PARTICIPANT</a> 
            </div>
         
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                    </li>
                
                    
                     <li>
                        <a  href="prgmreg.php"><i class="material-icons"style="font-size:30px;color:red;">add</i> REGISTER FOR EVENT</a>
                    </li>
                      <li>
                        <a  href="scheview3.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW SCHEDULE</a>
                    </li>
                    <li>
                        <a  href="eventview5.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW EVENTS</a>
                    </li>
                    
                </ul>
               
            </div>
             </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     
    <body>
        <a href="partentr.php">Back To Participant</a>
        <h1 align="center"> EVENT REGISTRATION</h1>
        <?php
$errors=array();
$db=mysqli_connect('localhost','root','','klp');
 if($db){
        echo "";
    }else{
        echo 'Error'.$db->error;
    }
$query=("SELECT * FROM `tbl_reg` join `tb_users` on tbl_reg.name=tb_users.fname where tb_users.login_id=$ss");
$results = mysqli_query($db, $query);
if($db){
        echo "";
    }else{
        echo 'Error'.$db->error;
    }
    ?>

                        <div class="">
                        <center><table   width="100%"   border="0" class="table table-bordered">
                            <tr><table border=5 bordercolor=black>
                           <thead style="color:red" align="center">
                            <th width="18%">NAME</th>
                            <th width="18%">PROGRAM 1</th>
                            <th width="18%">PROGRAM 2</th>
                            <th width="18%"> PROGRAM 3</th>
                            <th width="18%"> DELETE</th>
                            </thead>

  <?php
$numrows=mysqli_num_rows($results);
while($row=mysqli_fetch_assoc($results))
{
?>
<tbody style="color:black;" align="center">
<tr>
    <td><?php echo $row['name'];?></td>
    <td><?php echo $row['a'];?></td>
    <td><?php echo $row['b'];?></td>
    <td><?php echo $row['c'];?></td>
    <td style="padding:5px"><a href= "deletevnt.php?eid=<?php echo $row['eid']; ?>" class='btn btn-danger' >Delete</a></td>

</tr></tbody>
<?php
}
?>
<?php
echo"
</table>";

?>
        </div></center>
    </ul>
</body>
</html>