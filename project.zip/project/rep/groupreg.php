
<?php
include 'conn.php';
session_start();
$bb=$_SESSION['rep'];
echo $bb;
?>
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#ff9933;
letter-spacing: 0pt;
width:400px;
height: 300px;
border:30px ;
padding:40 px;
margin-top:70px;
margin-left: 400px;
text-align: center;
}
.ss{
  padding: 15px;
  font-size: 16px;
  color: black;
  background:#1aa3ff;
  border: none;
  border-radius: 4px;
}
.input-box1
{
width: 70%;
height: 60px;

    
    
    border-radius: 00px;
    padding: 0 10px;

</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">DISTRICT REP</a> 
            </div>
 
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                
                    
                   <li>
                        <a  href="stview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE PARTICIPANTS</a>
                    </li>
                    <li>
                        <a  href="groupreg.php"><i class="material-icons"style="font-size:30px;color:red;">add</i>GROUP EVENT REGISTRATIONS</a>
                    </li>
                      <li>
                        <a  href="scheview1.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW SCHEDULE</a>
                    </li>
                    <li>
                        <a  href="eventview2.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW/REMOVE EVENT REGISTRATIONS</a>
                    </li>
               
            </div>
             </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     
    <body>
        <a href="repenter.php">Back To Rep</a>
        <h1 align="center" style="color:red"> EVENT REGISTRATION</h1>

   
        <div class="a"><br>
    <h1 align="center">GROUP ITEMS</h1>
    <form method="POST" action="group_action.php">
        <br><br> <select name="list">
                  <option> SELECT THE GROUP ITEMS   </option>   
            <option>Group Song - Indian (10 mins)</option>
            <option>Group Song - Western (10 mins)</option>
            <option>Kolkkali (10 mins)</option>
            <option>Daffmuttu (10 mins)</option>
            <option>Oppana - Men (10 mins)</option>
            <option>Oppana - women (10 mins)</option>
            <option>Group Dance - Men (10 mins)</option>
            <option>Group Dance - Women (10 mins)</option>
            <option>Thiruvathirakali (10 mins)</option>
            <option>Margamkali (10 mins)</option>
            <option>Mime Drama (5 mins)</option>
            <option>Malayalam Drama (30 mins)</option>
            <option>English Drama (30 mins)</option>
            <option>Hindi Drama (30 mins)</option>
            <option>Pookkalam - Flower Carpet (3 hrs)</option>
            <option>ParichamuttuKali (10 mins)</option>
            <option>Folk Orchestra (10 mins)</option>
            <option>Skit - English/ Hindi (10 mins)</option>
            <option>poorakkali (10 mins)</option>
            <option>Koodiyattam (10 mins)</option>
            <option>Patriotic Song(5 mins)</option>
            <option>Ganamela(10 mins)</option>
            <option>Chendamelam(10 mins)</option>
            <option>Panchavadyam(20 mins)</option>
            <option>Band Melam(20 mins)</option>
            <option>Chenda/ thayampakam(10 mins)</option>
            <option>Maddalam(10 mins)</option>
              </select><br> 
   
<p>DISTRICT</p>
<?php 
$w= mysqli_query($conn,"SELECT * FROM `tbl_rep` join `tbl_district` on tbl_district.di_id = tbl_rep.d_id where tbl_rep.login_id='$bb'");
while($qw = mysqli_fetch_array($w))
{
    ?>
    <input type="text" name="district" value="<?php echo $qw['district']; ?>"></p><BR><br>
    <input type='submit'  class="btn" name='submit' value='Submit' /><br><br>
<?php
 }
?>


        
        
    </form>
    
  
    
    </div>  
    
    </ul>
</body>
</html>