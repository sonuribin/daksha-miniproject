
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klp";
$conn = new mysqli($servername,$username, $password,$dbname);

if(isset($_POST['submit'])){
$fname =$_POST['fname'];
$lname =$_POST['lname'];
$dob =  $_POST['dob'];
$gender = $_POST['gender'];
$district=$_POST['district'];
$phone =$_POST['phone'];
$email =$_POST['email'];
$password =$_POST['password'];



$query = "SELECT * FROM tbl_login WHERE email='$email' ";
$userId = mysqli_query($conn, $query);
if(mysqli_num_rows($userId) < 1){


$sql = "INSERT INTO tbl_login(email,password,utype_id) VALUES ('$email','$password',3)";

if (mysqli_query($conn, $sql)){
  
$fk = "SELECT * FROM tbl_login WHERE email='$email' ";
$logid = mysqli_query($conn, $query);
$l=mysqli_fetch_array($logid);
$details = "INSERT INTO tb_users(fname,lname,dob,gender,district,phone,login_id) VALUES ('$fname','$lname','$dob','$gender','$district','$phone','$l[login_id]')";

if(mysqli_query($conn, $details)) {


    echo "<script>alert('Successfully inserted');</script>";
header("Location:../plogin.php");

}}}else{
      echo "<script>alert('email in use');</script>";
}


}
mysqli_close($conn);
?>