<?php
$errors=array();
    $db=mysqli_connect('localhost','root','','klp');
    if($db){
        echo 'Success';
    }else{
        echo 'Error'.$db->error;
    }
    if(isset($_POST['submit'])===TRUE)
{
$list=mysqli_real_escape_string($db,$_POST['list']);
$stage=mysqli_real_escape_string($db,$_POST['stage']);
$date1=mysqli_real_escape_string($db,$_POST['date1']);
$time=mysqli_real_escape_string($db,$_POST['time']);
        $sql= "INSERT INTO tbl_sch (list,stage,date1,time) VALUES ('$list','$stage','$date1','$time')";
echo("Sql === ".$sql);
        if(mysqli_query($db,$sql)==TRUE){
    header("Location:staffentr.php");
}
else{
    echo("Sql===".$sql."Error ===".mysqli_error($db));
}
}
?>