<?php
include "conn.php";
?>
<head><title>REGISTRATION</title>
<link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#a4dee0;
letter-spacing: 0pt;
width:500px;
height: 250px;
border:10px ;
padding:40 px;
margin-top:80px;
margin-left: 400px;
text-align: center;
}



span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{

width: 88%;
height: 30px;
float: none;
    
    
    border-radius: 00px;
    padding: 0 10px;


}
.input-box1
{

width: 72%;
height: 30px;

    
    
    border-radius: 00px;
    padding: 0 20px;
}


.button
{
    background-color: #ff1100;
 height: 32px;
  color: white;
  padding: 2spx 32px;
  position: absolute;
  left: 320px;
  bottom: 30px;
  text-align: center;
  
  display: inline-block;
  font-size: 19px;
    border-radius: 12px;
.style1 {font-size: 10px}
}


</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">admin</a> 
            </div>
 
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                      <li>
                        <a  href="staff_reg.php"><i class="material-icons"style="font-size:30px;color:red;">supervisor_account</i> ADD A STAFF</a>
                    </li>
                    <li>
                        <a  href="rep_reg.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A REPRESENTATIVE</a>
                    </li>
						   <li  >
                        <a  href="eventview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW PROGRAM REGISTRATIONS</a>
                    </li>	
                      <li  >
                        <a  href="groupview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW GROUP EVENT REGISTRATION</a>
                    </li>
                    <li  >
                        <a  href="scheview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW SCHEDULE</a>
                    </li>				
					<li  >
                        <a  href="result2.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW RESULT</a>
                    </li>
                    <li  >
                        <a  href="stview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE STAFF</a>
                        <li  >
                             <a  href="repview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE REPRESENTATIVE</a>
                    </li>
                     <li  >
                             <a  href="districtadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A DISTRICT</a>
                    </li>
                
               
            </div>
            
        </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     <body>
                        <body>
    <a href="adminp.php">Back To Admin</a>
  <form action="district_action.php" method="POST" >
    <table class="table table-bordered">
      <h1>ADD DISTRICT</h1>
      <hr>


      <tr>
        <th>Enter district name:</th>
        <td><input type="text" name="district" id="district" class="form-control"/>
        </td>
      </tr>
      
     

   

      <div class="button">
                    
<button type="submit" class="button" name="submit" value="Register" >
                    <div align="center"><span class="style1"></span>Register
                    </div>
    </table>
  </form>


