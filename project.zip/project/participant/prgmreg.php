<?php
include 'conn.php';
session_start();
$ss=$_SESSION['users'];

?>
<head>
    <link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#ff9933;
letter-spacing: 0pt;
width:600px;
height: 600px;
border:30px ;
padding:40 px;
margin-top:70px;
margin-left: 300px;
text-align: center;
}
.ss{
  padding: 15px;
  font-size: 16px;
  color: black;
  background:#1aa3ff;
  border: none;
  border-radius: 4px;
}
.input-box1
{
width: 100%;
height: 60px;

    
    
    border-radius: 00px;
    padding: 0 10px;

</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">PARTICIPANT</a> 
            </div>
         
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>
                    </li>
                
                    
                     <li>
                        <a  href="prgmreg.php"><i class="material-icons"style="font-size:30px;color:red;">add</i> REGISTER FOR EVENT</a>
                    </li>
                      <li>
                        <a  href="scheview3.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW SCHEDULE</a>
                    </li>
                    <li>
                        <a  href="eventview5.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i>VIEW EVENTS</a>
                    </li>
                    
                </ul>
               
            </div>
             </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     
    <body>
        <a href="partentr.php">Back To Participant</a>
        <h1 align="center"> EVENT REGISTRATION</h1>
        
        
   
            <form method="post" action="prg_action.php">
            <div class="input-box"> 
<br><br><p align="center">ENTER YOUR NAME</p>
<?php 
$w= mysqli_query($conn,"SELECT fname FROM `tb_users` WHERE login_id=$ss");
while($qw = mysqli_fetch_array($w))
{
    ?>
    <input type="text" name="name" value="<?php echo $qw['fname']; ?>"></p><BR>
<?php
 }
?>


<h1>SINGLE ITEMS</h1>

        <div>
<P> ENTER YOUR ITEMS </p></P></div>
<div>
    <div class="input-box">
 <select name="a"><br>
    
   <option>  </option>
            <option>Mappilapattu - Male (5 mins)</option>
            <option>Mappilapattu - Female (5 mins)</option>
            <option>Light Music - Men (5 mins) </option>
            <option>Light Music - Women (10 mins) </option>
            <option>Classical Music - Men(10 mins)</option>
            <option>Classical Music - Women (10 mins)</option>
            <option>Kadhaprasangam (15 mins)</option>
            <option>Mono Act(5 mins)</option>
            <option>Mimicry (5 mins)</option>
            <option>Keralanadanam (15 mins)</option>
            <option>Thullal (10 mins)</option>
            <option>Kadhakali(Male) (15 mins)</option>
            <option>Kadhakali(Female) (15 mins)</option>
            <option>Folk Dance - Men (10 mins)</option>
            <option>Folk Dance - Women (10 mins)</option>
            <option>Bharatanatyam (15 mins)</option>
            <option>Classical Dance (Kuchipudi, Odissi) (15 mins)</option>
            <option>Mohiniyattam (15 mins)</option>
            <option>Recitation (5 mins)</option>
            <option>String Western - Violin, Guitar (10 mins)</option>
            <option>Wind Western - Harmonium (10 mins)</option>
            <option>Triple Drum  (10 mins)</option>
            <option>Jazz (10 mins)</option>
            <option>Percusion Type - Eastern - Chenda, Edakka (10 mins)</option>
            <option>Percusion Type - Eastern - Tabala, Panchavadyam (10 mins)</option>
            <option>Percusion Type - Eastern - Mridangam, Ganjira (10 mins)</option>
            <option>String Eastern - Veena (10 mins)</option>
            <option>String Eastern - Violin (10 mins)</option>
            <option>Wind Eastern - Harmonium, Pullamkuzhal (10 mins)</option>
            <option>Rangoli (2.5 hrs)</option>
            <option>Western Vocal - Solo (6 mins)</option>
            <option>Semi Classical - Solo (10 mins)</option>
            <option>Chakyarkkoothu (20 mins)</option>
            <option>KathakaliSangeetham -Male (10 mins)</option>
            <option>KathakaliSangeetham -Female (10 mins) </option>
          </select><br><br><br> 
        
          <select name="b">
                      

               <option>  </option>
            <option>Mappilapattu - Male (5 mins)</option>
            <option>Mappilapattu - Female (5 mins)</option>
            <option>Light Music - Men (5 mins) </option>
            <option>Light Music - Women (10 mins) </option>
            <option>Classical Music - Men(10 mins)</option>
            <option>Classical Music - Women (10 mins)</option>
            <option>Kadhaprasangam (15 mins)</option>
            <option>Mono Act(5 mins)</option>
            <option>Mimicry (5 mins)</option>
            <option>Keralanadanam (15 mins)</option>
            <option>Thullal (10 mins)</option>
            <option>Kadhakali(Male) (15 mins)</option>
            <option>Kadhakali(Female) (15 mins)</option>
            <option>Folk Dance - Men (10 mins)</option>
            <option>Folk Dance - Women (10 mins)</option>
            <option>Bharatanatyam (15 mins)</option>
            <option>Classical Dance (Kuchipudi, Odissi) (15 mins)</option>
            <option>Mohiniyattam (15 mins)</option>
            <option>Recitation (5 mins)</option>
            <option>String Western - Violin, Guitar (10 mins)</option>
            <option>Wind Western - Harmonium (10 mins)</option>
            <option>Triple Drum  (10 mins)</option>
            <option>Jazz (10 mins)</option>
            <option>Percusion Type - Eastern - Chenda, Edakka (10 mins)</option>
            <option>Percusion Type - Eastern - Tabala, Panchavadyam (10 mins)</option>
            <option>Percusion Type - Eastern - Mridangam, Ganjira (10 mins)</option>
            <option>String Eastern - Veena (10 mins)</option>
            <option>String Eastern - Violin (10 mins)</option>
            <option>Wind Eastern - Harmonium, Pullamkuzhal (10 mins)</option>
            <option>Rangoli (2.5 hrs)</option>
            <option>Western Vocal - Solo (6 mins)</option>
            <option>Semi Classical - Solo (10 mins)</option>
            <option>Chakyarkkoothu (20 mins)</option>
            <option>KathakaliSangeetham -Male (10 mins)</option>
            <option>KathakaliSangeetham -Female (10 mins) </option>
          </select><br><br><br> 

            
        
        
           <select name="c">
              <option>  </option>
            <option>Mappilapattu - Male (5 mins)</option>
            <option>Mappilapattu - Female (5 mins)</option>
            <option>Light Music - Men (5 mins) </option>
            <option>Light Music - Women (10 mins) </option>
            <option>Classical Music - Men(10 mins)</option>
            <option>Classical Music - Women (10 mins)</option>
            <option>Kadhaprasangam (15 mins)</option>
            <option>Mono Act(5 mins)</option>
            <option>Mimicry (5 mins)</option>
            <option>Keralanadanam (15 mins)</option>
            <option>Thullal (10 mins)</option>
            <option>Kadhakali(Male) (15 mins)</option>
            <option>Kadhakali(Female) (15 mins)</option>
            <option>Folk Dance - Men (10 mins)</option>
            <option>Folk Dance - Women (10 mins)</option>
            <option>Bharatanatyam (15 mins)/option>
            <option>Classical Dance (Kuchipudi, Odissi) (15 mins)</option>
            <option>Mohiniyattam (15 mins)</option>
            <option>Recitation (5 mins)</option>
            <option>String Western - Violin, Guitar (10 mins)</option>
            <option>Wind Western - Harmonium (10 mins)</option>
            <option>Triple Drum  (10 mins)</option>
            <option>Jazz (10 mins)</option>
            <option>Percusion Type - Eastern - Chenda, Edakka (10 mins)</option>
            <option>Percusion Type - Eastern - Tabala, Panchavadyam (10 mins)</option>
            <option>Percusion Type - Eastern - Mridangam, Ganjira (10 mins)</option>
            <option>String Eastern - Veena (10 mins)</option>
            <option>String Eastern - Violin (10 mins)</option>
            <option>Wind Eastern - Harmonium, Pullamkuzhal (10 mins)</option>
            <option>Rangoli (2.5 hrs)</option>
            <option>Western Vocal - Solo (6 mins)</option>
            <option>Semi Classical - Solo (10 mins)</option>
            <option>Chakyarkkoothu (20 mins)</option>
            <option>KathakaliSangeetham -Male (10 mins)</option>
            <option>KathakaliSangeetham -Female (10 mins) </option>
           
          </select><br><br><br>
           
        
          <input type='submit'  class="ss"name='submit' value='submit' />
       
</form>
           
         </div>  
        
    </body>
    
    </head>





