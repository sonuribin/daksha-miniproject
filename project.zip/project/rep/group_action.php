<?php
$errors=array();
    $db=mysqli_connect('localhost','root','','klp');
    if($db){
        echo 'Success';
    }else{
        echo 'Error'.$db->error;
    }
    if(isset($_POST['submit'])===TRUE)
{
$list=mysqli_real_escape_string($db,$_POST['list']);
$district=mysqli_real_escape_string($db,$_POST['district']);
        $sql= "INSERT INTO tbl_group (list,district) VALUES ('$list','$district')";
echo("Sql === ".$sql);
        if(mysqli_query($db,$sql)==TRUE){
    header("Location:groupreg.php");
}
else{
    echo("Sql===".$sql."Error ===".mysqli_error($db));
}
}
?>