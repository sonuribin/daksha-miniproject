<?php
	$uid=$_GET['uid'];
	include('conn.php');
	mysqli_query($conn,"delete from `tb_users` where uid='$uid'");
	header('location:stview.php');
?>