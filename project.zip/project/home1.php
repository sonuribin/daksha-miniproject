

<html>
<head>
    <script type="text/javascript">
  window.history.forward();
  function noBack() {
      window.history.forward();
  }
</script>

</head>
    <link rel="stylesheet" type="text/css" href="home2.css">

    <form>
        
    </form>
    <ul>
       
        <li><a href="reg.php">REGISTRATION</a>
            
        </li>
        <li><a href="plogin.php">LOGIN</a>
             
        </li> 
         <li><a>EVENT DETAILS</a>
        <ul>
            <li><a href="details.php">EVENT DETAILS</a></li>
            <li><a href="scview.php"> SCHEDULE</a></li>
        </ul>
        </li>
        <li><a href="resultview.php">RESULT</a></li>
           
       
        <li><a href="det.php"> ABOUT US</a>
            </li>
                

               
               
            </ul>
        </li>
        
        </li>
      
         
    
    </ul>
    <br><br><br><br><br><br><br><br>
    
    
      
        

 
   
    
</html>
