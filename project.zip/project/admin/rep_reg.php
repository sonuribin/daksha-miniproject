<?php
include "conn.php";
?>
<head><title>REGISTRATION</title>
<link rel="stylesheet" href="style2.css">
<style>
body
{
background-image: url("dancer-2349565.png");
text-shadow: hsla(hue, saturation, lightness, alpha);   
}
form
{
text-shadow: hsla(hue, saturation, lightness, alpha);
background-color:#e24646;
letter-spacing: 0pt;
width:300px;
height: 600px;
border:10px ;
padding:40 px;
margin-top:80px;
margin-left: 400px;
text-align: center;
}



span{
font-size: 16px;
margin-left: 10px;
font family: sans-serif;
}

.input-box
{

width: 88%;
height: 30px;
float: none;
    
    
    border-radius: 00px;
    padding: 0 10px;


}
.input-box1
{

width: 72%;
height: 30px;

    
    
    border-radius: 00px;
    padding: 0 20px;
}


.button
{
    background-color: #1aa3ff;
 height: 32px;
  color: white;
  padding: 2spx 32px;
  position: absolute;
  left: 250px;
  bottom: 30px;
  text-align: center;
  
  display: inline-block;
  font-size: 19px;
    border-radius: 12px;
.style1 {font-size: 10px}
}


</style>
</head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">admin</a> 
            </div>
 
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                      <li>
                        <a  href="staff_reg.php"><i class="material-icons"style="font-size:30px;color:red;">supervisor_account</i> ADD A STAFF</a>
                    </li>
                    <li>
                        <a  href="rep_reg.php"><i class="material-icons"style="font-size:30px;color:red;">person</i> ADD A REPRESENTATIVE</a>
                    </li>
						   <li  >
                        <a  href="eventview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW PROGRAM REGISTRATIONS</a>
                    </li>	
                      <li  >
                        <a  href="groupview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW GROUP EVENT REGISTRATION</a>
                    </li>
                    <li  >
                        <a  href="scheview.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW SCHEDULE</a>
                    </li>				
					<li  >
                        <a  href="result2.php"><i class="material-icons"style="font-size:30px;color:red;">visibility</i> VIEW RESULT</a>
                    </li>
                    <li  >
                        <a  href="stview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE STAFF</a>
                        <li  >
                             <a  href="repview.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> VIEW/REMOVE REPRESENTATIVE</a>
                    </li>
                     <li  >
                             <a  href="districtadd.php"><i class="material-icons"style="font-size:30px;color:red;">edit</i> ADD A DISTRICT</a>
                    </li>
                
               
            </div>
            
        </nav>  
        
        <hr>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     
                     <body>
                        <body>
    <a href="adminp.php">Back To Admin</a>
<div class="registerbox">
<h1 align="center" style="color:red">REPRESENTATIVE REGISTRATION</h1>
<form method="POST" action="codes/rep_action.php">
    <BR> <p align="center"><strong style="color: ghostwhite;">REPRESENTATIVE REGISTRATION</strong></p>
 <div>
        <BR><div class="input-box">
                        <span class="lnr lnr-user"></span>
                        <input name="fname" type="text" class="input-box" id="nme" title="First Name" onchange="Validate();" placeholder="Enter The First Name" required>
                    
    </div>
                    <span id="msg1" style="color:black;"></span>
<script>        
function Validate() 
{
    var val = document.getElementById('nme').value;

    if (!val.match(/^[A-Za-z]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Only alphabets are allowed!!";
                    document.getElementById('nme').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
<br>
                    <BR><div class="input-box">
                    <span class="lnr lnr-user"></span>
                    <input name="lname" type="text" class="input-box" id="lnme" title="Last Name" onchange="Validate1();" placeholder="Enter The Last Name" required>
                    </div>
                    <span id="msg2" style="color:black;"></span>
<script>        
function Validate1() 
{
    var val = document.getElementById('lnme').value;

    if (!val.match(/^[A-Za-z/./ /]{0,}$/)) 
    {
        document.getElementById('msg2').innerHTML="Only alphabets are allowed!!";
                    document.getElementById('lnme').value = "";
        return false;
    }
document.getElementById('msg2').innerHTML=" ";
    return true;
}
</script>
                    <br><?php
                    $qu="select * from tbl_district";
                    $s=mysqli_query($conn,$qu);
                    ?>
                
      </div>
      <select class="input-box1"  name="d_id" id="type" required>
      <option value=""disabled selected>Enter The District</option>
      <?php
while($d=mysqli_fetch_array($s))
{
    ?>
      <option value="<?php echo $d['di_id']; ?>"><?php echo $d['district']; ?></option>
      <?php } ?>
            
</select><BR><br>
<div class="input-box">
            <span class="lnr lnr-phone-handset"></span>
            <input name="phone" type="text" class="input-box" id="phn" title="Phone Number" onchange="Validat();" placeholder="Enter The Phone Number" required>
            </div>
            <span id="msg4" style="color:black;"></span>
            
<script>
function Validat() 
{
    var val = document.getElementById('phn').value;

    if (!val.match(/^[7-9][0-9]{1,9}$/)) 
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 10 number";
    
        
                    document.getElementById('phone').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}

</script>
        <br>            <BR><div class="input-box">
                        <span class="lnr lnr-envelope"></span>
                        <input type="email" name="email" id="email" title="E-Mail" class="input-box" placeholder="Enter The E-Mail [Eg: xyz@gmail.com]" required onchange="return Validata();">
                    </div>
                    <span id="msg5" style="color:black;"></span>
<script>        
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/))
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";
        
             document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

        </script>
        <br>
                    <BR><div class="input-box">
                        <span class="lnr lnr-lock"></span>
                        <input name="password" type="password" class="input-box" id="pwd" title="Password" onchange="return Validp();" placeholder="Enter the Password" required>
                    </div>
                    <span id="msg6" style="color:black;"></span>
<script>        
function Validp() 
{
    var val = document.getElementById('pwd').value;

    if (!val.match(/^[A-Za-z0-9!-*]{6,15}$/)) 
    {
        document.getElementById('msg6').innerHTML="Password should contain atleast 6 characters";
        
             document.getElementById('pwd').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}

</script>
                   <BR> <br><div class="input-box">
                        <span class="lnr lnr-lock"></span>
                        <input name="confirm" type="password" class="input-box" id="confirm" title="Confirm Password" onchange="return check();" placeholder="Enter the Confirm Password" required>
                    </div>
                    <span id="msg7" style="color:black;"></span>
                    <script>
    function check()
{
var pas1=document.getElementById("pwd");
                              var pas2=document.getElementById("confirm");
                            
                              if(pas1.value=="")
    {
        document.getElementById('msg7').innerHTML="Password can't be null!!";
        pas1.focus();
        return false;
    }
    if(pas2.value=="")
    {
        document.getElementById('msg7').innerHTML="Please confirm password!!";
        pass2.focus();
        return false;
    }
    if(pas1.value!=pas2.value)
    {
        document.getElementById('msg7').innerHTML="Passwords does not match!!";
        pas1.focus();
        return false;
    }
     document.getElementById('msg7').innerHTML=" "; 
    return true;
}
    </script>
    </div>
            <br>
            <div class="button">
                    
<button type="submit" class="button" name="submit" value="Register" >
                    <div align="center"><span class="style1"></span>Register
                    </div>
                    </button>
          </div>
</form>
</div>
  </body>
</head>
</html>
<?php
;
?>
