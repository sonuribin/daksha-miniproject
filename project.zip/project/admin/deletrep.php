<?php
	$id=$_GET['id'];
	$r_id=$_GET['r_id'];
	include('conn.php');
	mysqli_query($conn,"delete from `tbl_rep` where r_id='$r_id'");
	header('location:repview.php');
?>